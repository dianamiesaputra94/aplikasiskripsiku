﻿Imports System.Data.OleDb

Public Class MasterSekolah

    Sub Ketemu()
        'On Error Resume Next
        'txtnama.Enabled = False
        txtnama.Text = DR.Item("Nama")
        txtalamat.Text = DR.Item("alamat")
        txttelepon.Text = Microsoft.VisualBasic.Mid(DR.Item("telepon"), 9, 20)
        txtfax.Text = Microsoft.VisualBasic.Mid(DR.Item("fax"), 5, 20)
        txtemail.Text = Microsoft.VisualBasic.Mid(DR.Item("email"), 7, 43)
        txtwebsite.Text = Microsoft.VisualBasic.Mid(DR.Item("website"), 9, 41)
        txtnama.Focus()
    End Sub


    Sub TampilPerusahaan()
        CMD = New OleDbCommand("select * from tblsekolah", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            'txtnama.Enabled = False
            txtnama.Text = DR.Item("nama")
            txtalamat.Text = DR.Item("alamat")
            txttelepon.Text = Microsoft.VisualBasic.Mid(DR.Item("telepon"), 9, 21)
            txtfax.Text = Microsoft.VisualBasic.Mid(DR.Item("fax"), 5, 25)
            txtemail.Text = Microsoft.VisualBasic.Mid(DR.Item("email"), 7, 43)
            txtwebsite.Text = Microsoft.VisualBasic.Mid(DR.Item("website"), 9, 41)
        End If
    End Sub

    Private Sub MasterSekolah_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call TampilPerusahaan()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'CMD = New OledbCommand("select * from tblPerusahaan where nama='" & TextBox2.Text & "' and alamat='" & TextBox3.Text & "' and telepon='" & TextBox4.Text & "'", Conn)

        Dim hapusdulu As String = "delete from tblsekolah"
        CMD = New OleDbCommand(hapusdulu, Conn)
        CMD.ExecuteNonQuery()
        Dim simpan As String = "insert into tblsekolah values ('01','" & txtnama.Text & "','" & txtalamat.Text & "','" & Label4.Text & Space(1) & txttelepon.Text & "','" & Label5.Text & Space(1) & txtfax.Text & "','" & Label6.Text & Space(1) & txtemail.Text & "','" & Label7.Text & Space(1) & txtwebsite.Text & "')"
        CMD = New OleDbCommand(simpan, Conn)
        CMD.ExecuteNonQuery()
        MsgBox("Data berhasil disimpan")


        'CMD = New OleDbCommand("select * from tblsekolah where nama='" & txtnama.Text & "'", Conn)
        'DR = CMD.ExecuteReader
        'DR.Read()
        'Try
        '    If Not DR.HasRows Then
        '        Dim simpan As String = "insert into tblsekolah values ('01','" & txtnama.Text & "','" & txtalamat.Text & "','" & Label4.Text & Space(1) & txttelepon.Text & "','" & Label5.Text & Space(1) & txtfax.Text & "','" & Label6.Text & Space(1) & txtemail.Text & "','" & Label7.Text & Space(1) & txtwebsite.Text & "')"
        '        CMD = New OleDbCommand(simpan, Conn)
        '        CMD.ExecuteNonQuery()

        '        txtnama.Enabled = False
        '    Else

        '        Dim edit As String = "update tblsekolahset Nama='" & txtnama.Text & "',alamat='" & txtalamat.Text & "',telepon='" & Label4.Text & Space(1) & txttelepon.Text & "',fax='" & Label5.Text & Space(1) & txtfax.Text & "',email='" & Label6.Text & Space(1) & txtemail.Text & "',website='" & Label7.Text & Space(1) & txtwebsite.Text & "' where kode='01'"
        '        CMD = New OleDbCommand(edit, Conn)
        '        CMD.ExecuteNonQuery()
        '        MsgBox("Data berhasil diedit")
        '    End If


        CMD = New OleDbCommand("select * from tblsekolah", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            MenuUtama.Label1.Text = DR.Item(1) & Space(2) & DR.Item(2) & Space(2) & DR.Item(3) & Space(2) & DR.Item(4) & Space(2) & DR.Item(5) & Space(2) & DR.Item(6)

            MenuUtama.Label2.Text = DR.Item(1) & Space(2) & DR.Item(2) & Space(2) & DR.Item(3) & Space(2) & DR.Item(4) & Space(2) & DR.Item(5) & Space(2) & DR.Item(6)
        Else
            MenuUtama.Label1.Text = ""
            MenuUtama.Label2.Text = ""
        End If

        'Catch ex As Exception
        '    MsgBox(ex.Message)
        'End Try
    End Sub

    'Private Sub TextBox2_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtnama.LostFocus

    '    CMD = New OleDbCommand("select * from tblsekolah where KODE='01", Conn)
    '    DR = CMD.ExecuteReader
    '    DR.Read()
    '    If Not DR.HasRows Then
    '        txtalamat.Clear()
    '        txttelepon.Clear()
    '        txtfax.Clear()
    '        txtemail.Clear()
    '        txtwebsite.Clear()
    '        txtalamat.Focus()
    '    Else
    '        Call Ketemu()
    '    End If
    'End Sub
End Class

