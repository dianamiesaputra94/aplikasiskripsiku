﻿Imports System.Data.OleDb
Public Class Ujioledb

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            Try
                Koneksi()
                DA = New oledbDataAdapter(TextBox1.Text, CONN)
                DS = New DataSet
                DS.Clear()
                DA.Fill(DS)
                DGV.DataSource = DS.Tables(0)
                Dim TBL As DataTable = DS.Tables(0)
                If TBL.Rows.Count = 0 Then
                    MsgBox("Data tidak ditemukan")
                Else
                    'Label2.Text = TBL.Rows.Count & " Record"
                End If
            Catch ex As Exception
                MsgBox("Syntax oledb salah")
            End Try
        End If

    End Sub

End Class