﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UjianSiswa
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UjianSiswa))
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.FileSoal = New AxAcroPDFLib.AxAcroPDF
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lblketerangan = New System.Windows.Forms.Label
        Me.lbljumlahsalah = New System.Windows.Forms.Label
        Me.lbljumlahbenar = New System.Windows.Forms.Label
        Me.lbljumlahdijawab = New System.Windows.Forms.Label
        Me.lbljumlahsoal = New System.Windows.Forms.Label
        Me.lbldurasi = New System.Windows.Forms.Label
        Me.lblselesai = New System.Windows.Forms.Label
        Me.lblmulai = New System.Windows.Forms.Label
        Me.lbltanggal = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.DGV = New System.Windows.Forms.DataGridView
        Me.nomor = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Dijawab = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Jawaban = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Keterangan = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.BTNBatal = New System.Windows.Forms.Button
        Me.BTNPetunjuk = New System.Windows.Forms.Button
        Me.BTNTutup = New System.Windows.Forms.Button
        Me.BTNSelesai = New System.Windows.Forms.Button
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.tbataslulus = New System.Windows.Forms.Label
        Me.tidpelajaran = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.lblkelas = New System.Windows.Forms.Label
        Me.lblnis = New System.Windows.Forms.Label
        Me.lblnamasiswa = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.lbldijawab = New System.Windows.Forms.Label
        Me.lbljawaban = New System.Windows.Forms.Label
        Me.lblstatus = New System.Windows.Forms.Label
        Me.BTNJawab = New System.Windows.Forms.Button
        Me.RadioButton4 = New System.Windows.Forms.RadioButton
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.cmbidsoal = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.tpersen = New System.Windows.Forms.Label
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.FileSoal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.GroupBox1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.GroupBox3)
        Me.SplitContainer1.Size = New System.Drawing.Size(1261, 742)
        Me.SplitContainer1.SplitterDistance = 902
        Me.SplitContainer1.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.FileSoal)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(902, 742)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'FileSoal
        '
        Me.FileSoal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FileSoal.Enabled = True
        Me.FileSoal.Location = New System.Drawing.Point(3, 16)
        Me.FileSoal.Name = "FileSoal"
        Me.FileSoal.OcxState = CType(resources.GetObject("FileSoal.OcxState"), System.Windows.Forms.AxHost.State)
        Me.FileSoal.Size = New System.Drawing.Size(896, 723)
        Me.FileSoal.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.GroupBox2)
        Me.GroupBox3.Controls.Add(Me.DGV)
        Me.GroupBox3.Controls.Add(Me.GroupBox6)
        Me.GroupBox3.Controls.Add(Me.GroupBox5)
        Me.GroupBox3.Dock = System.Windows.Forms.DockStyle.Left
        Me.GroupBox3.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(391, 742)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.tpersen)
        Me.GroupBox2.Controls.Add(Me.tbataslulus)
        Me.GroupBox2.Controls.Add(Me.lblketerangan)
        Me.GroupBox2.Controls.Add(Me.lbljumlahsalah)
        Me.GroupBox2.Controls.Add(Me.lbljumlahbenar)
        Me.GroupBox2.Controls.Add(Me.lbljumlahdijawab)
        Me.GroupBox2.Controls.Add(Me.lbljumlahsoal)
        Me.GroupBox2.Controls.Add(Me.lbldurasi)
        Me.GroupBox2.Controls.Add(Me.lblselesai)
        Me.GroupBox2.Controls.Add(Me.lblmulai)
        Me.GroupBox2.Controls.Add(Me.lbltanggal)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(3, 451)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(385, 288)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        '
        'lblketerangan
        '
        Me.lblketerangan.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblketerangan.Location = New System.Drawing.Point(123, 201)
        Me.lblketerangan.Name = "lblketerangan"
        Me.lblketerangan.Size = New System.Drawing.Size(100, 20)
        Me.lblketerangan.TabIndex = 17
        Me.lblketerangan.Text = "-"
        '
        'lbljumlahsalah
        '
        Me.lbljumlahsalah.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbljumlahsalah.Location = New System.Drawing.Point(123, 181)
        Me.lbljumlahsalah.Name = "lbljumlahsalah"
        Me.lbljumlahsalah.Size = New System.Drawing.Size(100, 20)
        Me.lbljumlahsalah.TabIndex = 16
        Me.lbljumlahsalah.Text = "0"
        '
        'lbljumlahbenar
        '
        Me.lbljumlahbenar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbljumlahbenar.Location = New System.Drawing.Point(123, 161)
        Me.lbljumlahbenar.Name = "lbljumlahbenar"
        Me.lbljumlahbenar.Size = New System.Drawing.Size(100, 20)
        Me.lbljumlahbenar.TabIndex = 15
        Me.lbljumlahbenar.Text = "0"
        '
        'lbljumlahdijawab
        '
        Me.lbljumlahdijawab.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbljumlahdijawab.Location = New System.Drawing.Point(123, 129)
        Me.lbljumlahdijawab.Name = "lbljumlahdijawab"
        Me.lbljumlahdijawab.Size = New System.Drawing.Size(100, 20)
        Me.lbljumlahdijawab.TabIndex = 14
        Me.lbljumlahdijawab.Text = "0"
        '
        'lbljumlahsoal
        '
        Me.lbljumlahsoal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbljumlahsoal.Location = New System.Drawing.Point(123, 109)
        Me.lbljumlahsoal.Name = "lbljumlahsoal"
        Me.lbljumlahsoal.Size = New System.Drawing.Size(100, 20)
        Me.lbljumlahsoal.TabIndex = 13
        Me.lbljumlahsoal.Text = "0"
        '
        'lbldurasi
        '
        Me.lbldurasi.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbldurasi.Location = New System.Drawing.Point(123, 89)
        Me.lbldurasi.Name = "lbldurasi"
        Me.lbldurasi.Size = New System.Drawing.Size(100, 20)
        Me.lbldurasi.TabIndex = 12
        Me.lbldurasi.Text = "0"
        '
        'lblselesai
        '
        Me.lblselesai.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblselesai.Location = New System.Drawing.Point(123, 59)
        Me.lblselesai.Name = "lblselesai"
        Me.lblselesai.Size = New System.Drawing.Size(100, 20)
        Me.lblselesai.TabIndex = 11
        Me.lblselesai.Text = "Label13"
        '
        'lblmulai
        '
        Me.lblmulai.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblmulai.Location = New System.Drawing.Point(123, 39)
        Me.lblmulai.Name = "lblmulai"
        Me.lblmulai.Size = New System.Drawing.Size(100, 20)
        Me.lblmulai.TabIndex = 10
        Me.lblmulai.Text = "Label12"
        '
        'lbltanggal
        '
        Me.lbltanggal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbltanggal.Location = New System.Drawing.Point(123, 19)
        Me.lbltanggal.Name = "lbltanggal"
        Me.lbltanggal.Size = New System.Drawing.Size(100, 20)
        Me.lbltanggal.TabIndex = 9
        Me.lbltanggal.Text = "Label11"
        '
        'Label10
        '
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label10.Location = New System.Drawing.Point(17, 201)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 20)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Keterangan"
        '
        'Label9
        '
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Location = New System.Drawing.Point(17, 181)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 20)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Jumlah Salah"
        '
        'Label8
        '
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Location = New System.Drawing.Point(17, 161)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 20)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Jumlah Benar"
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Location = New System.Drawing.Point(17, 129)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 20)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Jumlah Dijawab"
        '
        'Label6
        '
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Location = New System.Drawing.Point(17, 109)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 20)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Jumlah Soal"
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Location = New System.Drawing.Point(17, 89)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 20)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Durasi"
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Location = New System.Drawing.Point(17, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 20)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Selesai"
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Location = New System.Drawing.Point(17, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 20)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Mulai"
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Location = New System.Drawing.Point(17, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 20)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Tanggal"
        '
        'DGV
        '
        Me.DGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.nomor, Me.Dijawab, Me.Jawaban, Me.Keterangan})
        Me.DGV.Dock = System.Windows.Forms.DockStyle.Top
        Me.DGV.Location = New System.Drawing.Point(3, 375)
        Me.DGV.Name = "DGV"
        Me.DGV.Size = New System.Drawing.Size(385, 76)
        Me.DGV.TabIndex = 6
        Me.DGV.Visible = False
        '
        'nomor
        '
        Me.nomor.HeaderText = "Nomor"
        Me.nomor.Name = "nomor"
        Me.nomor.Width = 63
        '
        'Dijawab
        '
        Me.Dijawab.HeaderText = "Dijawab"
        Me.Dijawab.Name = "Dijawab"
        Me.Dijawab.Width = 70
        '
        'Jawaban
        '
        Me.Jawaban.HeaderText = "Jawaban"
        Me.Jawaban.Name = "Jawaban"
        Me.Jawaban.Width = 75
        '
        'Keterangan
        '
        Me.Keterangan.HeaderText = "Keterangan"
        Me.Keterangan.Name = "Keterangan"
        Me.Keterangan.Width = 87
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.BTNBatal)
        Me.GroupBox6.Controls.Add(Me.BTNPetunjuk)
        Me.GroupBox6.Controls.Add(Me.BTNTutup)
        Me.GroupBox6.Controls.Add(Me.BTNSelesai)
        Me.GroupBox6.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox6.Location = New System.Drawing.Point(3, 305)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(385, 70)
        Me.GroupBox6.TabIndex = 25
        Me.GroupBox6.TabStop = False
        '
        'BTNBatal
        '
        Me.BTNBatal.Dock = System.Windows.Forms.DockStyle.Left
        Me.BTNBatal.Location = New System.Drawing.Point(279, 16)
        Me.BTNBatal.Name = "BTNBatal"
        Me.BTNBatal.Size = New System.Drawing.Size(92, 51)
        Me.BTNBatal.TabIndex = 21
        Me.BTNBatal.Text = "Batal"
        Me.BTNBatal.UseVisualStyleBackColor = True
        '
        'BTNPetunjuk
        '
        Me.BTNPetunjuk.Dock = System.Windows.Forms.DockStyle.Left
        Me.BTNPetunjuk.Location = New System.Drawing.Point(187, 16)
        Me.BTNPetunjuk.Name = "BTNPetunjuk"
        Me.BTNPetunjuk.Size = New System.Drawing.Size(92, 51)
        Me.BTNPetunjuk.TabIndex = 18
        Me.BTNPetunjuk.Text = "Petunjuk"
        Me.BTNPetunjuk.UseVisualStyleBackColor = True
        '
        'BTNTutup
        '
        Me.BTNTutup.Dock = System.Windows.Forms.DockStyle.Left
        Me.BTNTutup.Location = New System.Drawing.Point(95, 16)
        Me.BTNTutup.Name = "BTNTutup"
        Me.BTNTutup.Size = New System.Drawing.Size(92, 51)
        Me.BTNTutup.TabIndex = 20
        Me.BTNTutup.Text = "Tutup"
        Me.BTNTutup.UseVisualStyleBackColor = True
        '
        'BTNSelesai
        '
        Me.BTNSelesai.Dock = System.Windows.Forms.DockStyle.Left
        Me.BTNSelesai.Location = New System.Drawing.Point(3, 16)
        Me.BTNSelesai.Name = "BTNSelesai"
        Me.BTNSelesai.Size = New System.Drawing.Size(92, 51)
        Me.BTNSelesai.TabIndex = 19
        Me.BTNSelesai.Text = "Selesai"
        Me.BTNSelesai.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.tidpelajaran)
        Me.GroupBox5.Controls.Add(Me.Label30)
        Me.GroupBox5.Controls.Add(Me.Label29)
        Me.GroupBox5.Controls.Add(Me.Label28)
        Me.GroupBox5.Controls.Add(Me.lblkelas)
        Me.GroupBox5.Controls.Add(Me.lblnis)
        Me.GroupBox5.Controls.Add(Me.lblnamasiswa)
        Me.GroupBox5.Controls.Add(Me.Label25)
        Me.GroupBox5.Controls.Add(Me.Label26)
        Me.GroupBox5.Controls.Add(Me.GroupBox4)
        Me.GroupBox5.Controls.Add(Me.ListBox1)
        Me.GroupBox5.Controls.Add(Me.cmbidsoal)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox5.Location = New System.Drawing.Point(3, 16)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(385, 289)
        Me.GroupBox5.TabIndex = 24
        Me.GroupBox5.TabStop = False
        '
        'tbataslulus
        '
        Me.tbataslulus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tbataslulus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbataslulus.Location = New System.Drawing.Point(229, 161)
        Me.tbataslulus.Name = "tbataslulus"
        Me.tbataslulus.Size = New System.Drawing.Size(100, 20)
        Me.tbataslulus.TabIndex = 27
        '
        'tidpelajaran
        '
        Me.tidpelajaran.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tidpelajaran.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tidpelajaran.Location = New System.Drawing.Point(207, 56)
        Me.tidpelajaran.Name = "tidpelajaran"
        Me.tidpelajaran.Size = New System.Drawing.Size(100, 20)
        Me.tidpelajaran.TabIndex = 26
        '
        'Label30
        '
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(101, 96)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(252, 20)
        Me.Label30.TabIndex = 25
        '
        'Label29
        '
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label29.Location = New System.Drawing.Point(10, 96)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(85, 20)
        Me.Label29.TabIndex = 24
        Me.Label29.Text = "Soal Ujian"
        '
        'Label28
        '
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label28.Location = New System.Drawing.Point(10, 56)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(85, 20)
        Me.Label28.TabIndex = 23
        Me.Label28.Text = "Kelas"
        '
        'lblkelas
        '
        Me.lblkelas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblkelas.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblkelas.Location = New System.Drawing.Point(101, 56)
        Me.lblkelas.Name = "lblkelas"
        Me.lblkelas.Size = New System.Drawing.Size(100, 20)
        Me.lblkelas.TabIndex = 22
        '
        'lblnis
        '
        Me.lblnis.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblnis.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnis.Location = New System.Drawing.Point(101, 16)
        Me.lblnis.Name = "lblnis"
        Me.lblnis.Size = New System.Drawing.Size(100, 20)
        Me.lblnis.TabIndex = 21
        '
        'lblnamasiswa
        '
        Me.lblnamasiswa.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblnamasiswa.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnamasiswa.Location = New System.Drawing.Point(101, 36)
        Me.lblnamasiswa.Name = "lblnamasiswa"
        Me.lblnamasiswa.Size = New System.Drawing.Size(247, 20)
        Me.lblnamasiswa.TabIndex = 20
        '
        'Label25
        '
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label25.Location = New System.Drawing.Point(10, 16)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(85, 20)
        Me.Label25.TabIndex = 19
        Me.Label25.Text = "NIS"
        '
        'Label26
        '
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label26.Location = New System.Drawing.Point(10, 36)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(85, 20)
        Me.Label26.TabIndex = 18
        Me.Label26.Text = "Nama Siswa"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.lbldijawab)
        Me.GroupBox4.Controls.Add(Me.lbljawaban)
        Me.GroupBox4.Controls.Add(Me.lblstatus)
        Me.GroupBox4.Controls.Add(Me.BTNJawab)
        Me.GroupBox4.Controls.Add(Me.RadioButton4)
        Me.GroupBox4.Controls.Add(Me.RadioButton3)
        Me.GroupBox4.Controls.Add(Me.RadioButton2)
        Me.GroupBox4.Controls.Add(Me.RadioButton1)
        Me.GroupBox4.Location = New System.Drawing.Point(76, 123)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(292, 157)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Jawaban Anda "
        '
        'lbldijawab
        '
        Me.lbldijawab.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbldijawab.Location = New System.Drawing.Point(205, 23)
        Me.lbldijawab.Name = "lbldijawab"
        Me.lbldijawab.Size = New System.Drawing.Size(82, 20)
        Me.lbldijawab.TabIndex = 20
        Me.lbldijawab.Text = "Label20"
        Me.lbldijawab.Visible = False
        '
        'lbljawaban
        '
        Me.lbljawaban.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbljawaban.Location = New System.Drawing.Point(205, 50)
        Me.lbljawaban.Name = "lbljawaban"
        Me.lbljawaban.Size = New System.Drawing.Size(82, 20)
        Me.lbljawaban.TabIndex = 19
        Me.lbljawaban.Text = "Label21"
        Me.lbljawaban.Visible = False
        '
        'lblstatus
        '
        Me.lblstatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblstatus.Location = New System.Drawing.Point(205, 78)
        Me.lblstatus.Name = "lblstatus"
        Me.lblstatus.Size = New System.Drawing.Size(82, 20)
        Me.lblstatus.TabIndex = 18
        Me.lblstatus.Text = "Label22"
        Me.lblstatus.Visible = False
        '
        'BTNJawab
        '
        Me.BTNJawab.Location = New System.Drawing.Point(15, 127)
        Me.BTNJawab.Name = "BTNJawab"
        Me.BTNJawab.Size = New System.Drawing.Size(75, 23)
        Me.BTNJawab.TabIndex = 4
        Me.BTNJawab.Text = "Jawab"
        Me.BTNJawab.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(18, 95)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(33, 17)
        Me.RadioButton4.TabIndex = 3
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "D"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(18, 72)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(32, 17)
        Me.RadioButton3.TabIndex = 2
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "C"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(18, 49)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(32, 17)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "B"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(18, 26)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(32, 17)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "A"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(6, 123)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(59, 160)
        Me.ListBox1.TabIndex = 3
        '
        'cmbidsoal
        '
        Me.cmbidsoal.FormattingEnabled = True
        Me.cmbidsoal.Location = New System.Drawing.Point(101, 76)
        Me.cmbidsoal.Name = "cmbidsoal"
        Me.cmbidsoal.Size = New System.Drawing.Size(252, 21)
        Me.cmbidsoal.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Location = New System.Drawing.Point(10, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID Soal"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 1000
        '
        'tpersen
        '
        Me.tpersen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpersen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tpersen.Location = New System.Drawing.Point(229, 181)
        Me.tpersen.Name = "tpersen"
        Me.tpersen.Size = New System.Drawing.Size(100, 20)
        Me.tpersen.TabIndex = 28
        '
        'UjianSiswa
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1261, 742)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "UjianSiswa"
        Me.Text = "Ujian Siswa"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.FileSoal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents FileSoal As AxAcroPDFLib.AxAcroPDF
    Friend WithEvents BTNBatal As System.Windows.Forms.Button
    Friend WithEvents DGV As System.Windows.Forms.DataGridView
    Friend WithEvents nomor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dijawab As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Jawaban As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Keterangan As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BTNTutup As System.Windows.Forms.Button
    Friend WithEvents BTNSelesai As System.Windows.Forms.Button
    Friend WithEvents BTNPetunjuk As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents lblkelas As System.Windows.Forms.Label
    Friend WithEvents lblnis As System.Windows.Forms.Label
    Friend WithEvents lblnamasiswa As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents lbldijawab As System.Windows.Forms.Label
    Friend WithEvents lbljawaban As System.Windows.Forms.Label
    Friend WithEvents lblstatus As System.Windows.Forms.Label
    Friend WithEvents BTNJawab As System.Windows.Forms.Button
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents cmbidsoal As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblketerangan As System.Windows.Forms.Label
    Friend WithEvents lbljumlahsalah As System.Windows.Forms.Label
    Friend WithEvents lbljumlahbenar As System.Windows.Forms.Label
    Friend WithEvents lbljumlahdijawab As System.Windows.Forms.Label
    Friend WithEvents lbljumlahsoal As System.Windows.Forms.Label
    Friend WithEvents lbldurasi As System.Windows.Forms.Label
    Friend WithEvents lblselesai As System.Windows.Forms.Label
    Friend WithEvents lblmulai As System.Windows.Forms.Label
    Friend WithEvents lbltanggal As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tidpelajaran As System.Windows.Forms.Label
    Friend WithEvents tbataslulus As System.Windows.Forms.Label
    Friend WithEvents tpersen As System.Windows.Forms.Label
End Class
