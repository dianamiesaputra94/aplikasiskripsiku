﻿Imports System.Data.OleDb

Public Class Ujian

    Private Sub Ujian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label11.Text = Format(Today, "MM/dd/yyyy")
        Call Koneksi()
        'tampilkan mata kuliah yang cocok dengan hasil login yang tercantum di panel1 menu utama (sesuai jurusan)
        CMD = New oledbCommand("select * from tblkuliah WHERE LEFT(IDKULIAH,1)='" & Trim(Microsoft.VisualBasic.Mid(MenuUtama.Panel1.Text, 4, 1)) & "'", CONN)
        DR = CMD.ExecuteReader
        ComboBox1.Items.Clear()
        Do While DR.Read
            ComboBox1.Items.Add(DR.Item("Idkuliah") & Space(5) & DR.Item("matakuliah"))
        Loop
        Label14.Text = 0
        Label15.Text = 0
        Label16.Text = 0
        Label17.Text = 0
        Label18.Text = 0
        Label19.Text = "-"
        DGV.ReadOnly = True
        DGV.Rows.Clear()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        'cari data NIM yang pernah melakukan ujian di mata kuliah yang dipilih di combobox1
        CMD = New OleDbCommand("select * from tblmasterjawaban where nim='" & Label23.Text & "' and idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            'jika sudah ada maka tampilkan pesan
            MsgBox("Anda sudah mengikuti test mata kuliah ini " & Chr(13) & _
                    "Tanggal    :" & Format(DR.Item("tanggal"), "dd-MMM-yyyy") & " " & Chr(13) & _
                    "Mulai      :" & Format(DR.Item("Mulai"), "hh:mm:ss") & " " & vbCrLf & _
                    "Selesai    :" & Format(DR.Item("selesai"), "hh:mm:ss") & " " & vbCrLf & _
                    "Jml Soal   :" & DR.Item("jmlsoal") & " " & vbCrLf & _
                    "Dijawab    :" & DR.Item("dijawab") & " " & vbCrLf & _
                    "Jml Benar  :" & DR.Item("benar") & " " & vbCrLf & _
                    "Jml Salah  :" & DR.Item("salah") & " " & vbCrLf & _
                    "Keterangan :" & DR.Item("keterangan") & " ")
            Exit Sub
        End If

        'jika belum ada maka tampilkan nomor soal ujiannya
        CMD = New OleDbCommand("select nomor from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "' order by 1", Conn)
        DR = CMD.ExecuteReader
        ListBox1.Items.Clear()
        Do While DR.Read
            ListBox1.Items.Add(DR.Item("Nomor"))
        Loop
        ListBox1.Focus()
    End Sub


    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Call BersihkanJawaban()
        'tampilkan pertanyaan soal ujian dalam textbox1 sesuai dengan nomor soal yang dipilih
        CMD = New OleDbCommand("select * from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "' and VAL(nomor)='" & Val(ListBox1.Text) & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            TextBox1.Text = DR.Item("pertanyaan")
            RadioButton1.Text = DR.Item("A")
            RadioButton2.Text = DR.Item("B")
            RadioButton3.Text = DR.Item("C")
            RadioButton4.Text = DR.Item("D")
        End If
    End Sub

    Sub BersihkanJawaban()
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        RadioButton4.Checked = False
    End Sub

    Private Sub RadioButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton1.Click
        'jika jawaban A dipilih maka lakukan proses penyesuaian jawaban apakah benar atau salah
        CMD = New OleDbCommand("select * from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "' and VAL(nomor)='" & ListBox1.Text & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Label20.Text = "A"
            Label21.Text = DR.Item("Jawaban")
            If Label20.Text = Label21.Text Then Label22.Text = "BENAR" Else Label22.Text = "SALAH"
        End If
    End Sub

    Private Sub RadioButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton2.Click
        'jika jawaban B dipilih maka lakukan proses penyesuaian jawaban apakah benar atau salah
        CMD = New OleDbCommand("select * from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "' and VAL(nomor)='" & ListBox1.Text & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Label20.Text = "B"
            Label21.Text = DR.Item("Jawaban")
            If Label20.Text = Label21.Text Then Label22.Text = "BENAR" Else Label22.Text = "SALAH"
        End If
    End Sub

    Private Sub RadioButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton3.Click
        'jika jawaban C dipilih maka lakukan proses penyesuaian jawaban apakah benar atau salah
        CMD = New OleDbCommand("select * from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "' and VAL(nomor)='" & ListBox1.Text & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Label20.Text = "C"
            Label21.Text = DR.Item("Jawaban")
            If Label20.Text = Label21.Text Then Label22.Text = "BENAR" Else Label22.Text = "SALAH"
        End If
    End Sub

    Private Sub RadioButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton4.Click
        'jika jawaban D dipilih maka lakukan proses penyesuaian jawaban apakah benar atau salah
        CMD = New OleDbCommand("select * from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "' and VAL(nomor)='" & ListBox1.Text & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Label20.Text = "D"
            Label21.Text = DR.Item("Jawaban")
            If Label20.Text = Label21.Text Then Label22.Text = "BENAR" Else Label22.Text = "SALAH"
        End If
    End Sub


    Private Sub BTNJawab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNJawab.Click
        'jika mata kuliah belum dipilih
        If ComboBox1.Text = "" Then
            MsgBox("Anda belum memilih mata kuliah")
            Exit Sub
        End If
        'jika belum memeilih nomor soal
        If ListBox1.Text = "" Or TextBox1.Text = "" Then
            MsgBox("Anda belum memilih nomor soal")
            Exit Sub
        End If

        'jika belum memilih jawaban
        If RadioButton1.Checked = False And RadioButton2.Checked = False And RadioButton3.Checked = False And RadioButton4.Checked = False Then
            MsgBox("Anda belum memilih jawaban")
            Exit Sub
        End If

        'jika nomor soal tersebut sudah dijawab
        For BARIS As Integer = 0 To DGV.RowCount - 1
            If ListBox1.Text = DGV.Rows(BARIS).Cells(0).Value Then
                MsgBox("Nomor ini sudah dijawab")
                Exit Sub
            End If
        Next
        'jawaban akan tampil di dalam grid sebelah kanan
        DGV.Rows.Add(ListBox1.Text, Label20.Text, Label21.Text, Label22.Text)
        ListBox1.Focus()
        ListBox1.SelectedItem = ListBox1.SelectedItem + 1
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label12.Text = TimeOfDay
        Timer1.Enabled = False
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Label13.Text = TimeOfDay
    End Sub

    'membuat fungsi untuk menghitung jumlah jawaban yang benar
    Sub JumlahBenar()
        Dim hitung As Integer = 0
        For baris As Integer = 0 To DGV.RowCount - 2
            If DGV.Rows(baris).Cells(3).Value = "BENAR" Then
                hitung = hitung + 1
                Label17.Text = hitung
            End If
        Next
    End Sub

    'membuat fungsi untuk menghitung jumlah jawaban yang benar
    Sub JumlahSalah()
        Dim hitung As Integer = 0
        For baris As Integer = 0 To DGV.RowCount - 2
            If DGV.Rows(baris).Cells(3).Value = "SALAH" Then
                hitung = hitung + 1
                Label18.Text = hitung
            End If
        Next
    End Sub

    Private Sub BTNSelesai_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNSelesai.Click
        Try
            'ketika BTNselesai di klik maka....
            Timer2.Enabled = False
            Dim awal As Date = TimeValue(Label12.Text)
            Dim hasil As TimeSpan = Now - awal
            'hitung durasi pengerjaan soal ujian
            Label14.Text = (String.Format("{0}:{1}:{2}", hasil.Hours, hasil.Minutes, hasil.Seconds))

            'hitung banyaknya nomor soal ujian
            Label15.Text = ListBox1.Items.Count
            Label16.Text = DGV.RowCount - 1

            Call JumlahBenar()
            Call JumlahSalah()
            'jika jumlah benar > jumlah salah maka "LULUS"
            If Val(Label17.Text) > Val(Label18.Text) Then
                Label19.Text = "LULUS"
            Else
                Label19.Text = "GAGAL"
            End If

            'simoan semua hasil ujian ke tabel detail jawaban
            For baris As Integer = 0 To DGV.RowCount - 2
                Dim simpandetail As String = "insert into tbldetailjawaban values ('" & Label23.Text & "','" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "','" & DGV.Rows(baris).Cells(0).Value & "','" & DGV.Rows(baris).Cells(1).Value & "','" & DGV.Rows(baris).Cells(2).Value & "','" & DGV.Rows(baris).Cells(3).Value & "')"
                CMD = New OleDbCommand(simpandetail, Conn)
                CMD.ExecuteNonQuery()
            Next

            'simpan summary hasil ujian ke tabel master jawaban
            Dim simpanmaster As String = "insert into tblmasterjawaban values ('" & Label23.Text & "','" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "','" & Label11.Text & "','" & Label12.Text & "','" & Label13.Text & "','" & Label14.Text & "','" & Label15.Text & "','" & Label16.Text & "','" & Label17.Text & "','" & Label18.Text & "','" & Label19.Text & "')"
            CMD = New OleDbCommand(simpanmaster, Conn)
            CMD.ExecuteNonQuery()
            ComboBox1.Enabled = False
            ListBox1.Enabled = False
            BTNJawab.Enabled = False
            RadioButton1.Enabled = False
            RadioButton2.Enabled = False
            RadioButton3.Enabled = False
            RadioButton4.Enabled = False
            BTNSelesai.Enabled = False
            ComboBox1.Text = ""
            ListBox1.Items.Clear()
            TextBox1.Clear()
            Call BersihkanJawaban()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BTNTutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNTutup.Click
        ComboBox1.Text = ""
        ListBox1.Items.Clear()
        TextBox1.Clear()
        DGV.Rows.Clear()
        Me.Close()
    End Sub

    Private Sub BTNPetunjuk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNPetunjuk.Click
        MsgBox("1. Pilih Materi di combo paling atas" & Chr(13) & _
        "2. Pilih Nomor Soal dalam list di sebelah kiri" & Chr(13) & _
        "3. Pilih Jawaban pada option button" & vbCrLf & _
        "4. Klik Jawab" & vbCrLf & _
        "5. Lanjutkan ke soal nomor Berikutnya")
    End Sub

    Private Sub BTNBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNBatal.Click
        ComboBox1.Text = ""
        ListBox1.Items.Clear()
        TextBox1.Clear()
        DGV.Rows.Clear()
        Call BersihkanJawaban()
    End Sub
End Class