﻿Imports System.Data.OleDb

Public Class DataPelajaran

    Sub notis()
        CMD = New OleDbCommand("select idpelajaran from tblpelajaran order by 1 desc", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If Not DR.HasRows Then
            tid.Text = "001"
        Else
            tid.Text = Format(Microsoft.VisualBasic.Right(DR.Item(0), 3) + 1, "000")
        End If
    End Sub

    Sub Kosongkan()
        'tid.Clear()
        tid.Enabled = False
        Call notis()
        tnama.Clear()
        tkkm.Clear()
        ComboBox1.Text = ""
        TextBox4.Clear()
        tid.Enabled = False
        tnama.Enabled = True
        tkkm.Enabled = True
        Call tampilkelas()
        tnama.Focus()
    End Sub

    Sub Tampilgrid()
        DA = New OleDbDataAdapter("select * from TBLPelajaran", Conn)
        DS = New DataSet
        DA.Fill(DS)
        DGV.DataSource = DS.Tables(0)
        DGV.ReadOnly = True
    End Sub

    Sub tampilkelas()
        CMD = New OleDbCommand("select distinct kelas from tblsiswa", Conn)
        DR = CMD.ExecuteReader
        ComboBox1.Items.Clear()
        Do While DR.Read
            ComboBox1.Items.Add(DR(0))
        Loop
    End Sub

    Private Sub DataMataPelajaran_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call Kosongkan()
        Call Tampilgrid()
        'tid.Enabled = False
    End Sub


    Private Sub Textbox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tnama.KeyPress
        If e.KeyChar = Chr(13) Then
            tkkm.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tkkm.KeyPress
        tkkm.MaxLength = 5
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9" Or e.KeyChar = vbBack) Then
            e.Handled = True
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If tid.Text = "" Or tnama.Text = "" Or tkkm.Text = "" Or ComboBox1.Text = "" Then
            MsgBox("data belum lengkap")
            Exit Sub
        Else
            Call Koneksi()
            'cari kode mata Pelajaran
            CMD = New OleDbCommand("select * from TBLPelajaran where idPelajaran='" & tid.Text & "'", Conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If Not DR.HasRows Then
                Call Koneksi()
                'jika tidak ada maka lakukan insert
                Dim simpan As String = "insert into TBLPelajaran values('" & tid.Text & "','" & tnama.Text & "','" & tkkm.Text & "','" & ComboBox1.Text & "')"
                CMD = New OleDbCommand(simpan, Conn)
                CMD.ExecuteNonQuery()
            Else
                Call Koneksi()
                'jika sudah ada maka lakukan update
                Dim edit As String = "update TBLPelajaran set MataPelajaran='" & tnama.Text & "',KKM='" & tkkm.Text & "',kelas='" & ComboBox1.Text & "' where idPelajaran='" & tid.Text & "'"
                CMD = New OleDbCommand(edit, Conn)
                CMD.ExecuteNonQuery()
            End If
            Call Kosongkan()
            Call Tampilgrid()
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Call Kosongkan()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If tnama.Text = "" Then
            MsgBox("id Pelajaran harus diisi dulu")
            tnama.Focus()
            Exit Sub
        Else
            If MessageBox.Show("hapus data ini...?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call Koneksi()
                Dim hapus As String = "delete from TBLPelajaran where idPelajaran='" & tid.Text & "'"
                CMD = New OleDbCommand(hapus, Conn)
                CMD.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilgrid()
            Else
                Call Kosongkan()
            End If
        End If
    End Sub

    Private Sub DGV_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DGV.CellMouseClick
        On Error Resume Next
        tid.Enabled = False
        tid.Text = DGV.Rows(e.RowIndex).Cells(0).Value
        tnama.Text = DGV.Rows(e.RowIndex).Cells(1).Value
        tkkm.Text = DGV.Rows(e.RowIndex).Cells(2).Value
        ComboBox1.Text = DGV.Rows(e.RowIndex).Cells(3).Value
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        Call Koneksi()
        CMD = New OleDbCommand("select * from TBLPelajaran where MataPelajaran like '%" & TextBox4.Text & "%'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Call Koneksi()
            DA = New OleDbDataAdapter("select * from TBLPelajaran where MataPelajaran like '%" & TextBox4.Text & "%'", Conn)
            DS = New DataSet
            DA.Fill(DS)
            DGV.DataSource = DS.Tables(0)
        Else
            MsgBox("Mata Pelajaran tidak ditemukan")
        End If
    End Sub


End Class
