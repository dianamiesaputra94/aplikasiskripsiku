﻿Imports System.Data.OleDb

Public Class LaporanMaster

    Private Sub LaporanMaster_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()

        CMD = New OleDbCommand("select distinct kelas from tblsiswa", Conn)
        DR = CMD.ExecuteReader
        ComboBox1.Items.Clear()
        Do While DR.Read
            ComboBox1.Items.Add(DR.Item("kelas"))
        Loop

        CMD = New OleDbCommand("select nama from tblsiswa", Conn)
        DR = CMD.ExecuteReader
        ComboBox2.Items.Clear()
        Do While DR.Read
            ComboBox2.Items.Add(DR.Item("nama"))
        Loop

        CMD = New OleDbCommand("select matapelajaran from tblpelajaran", Conn)
        DR = CMD.ExecuteReader
        ComboBox3.Items.Clear()
        Do While DR.Read
            ComboBox3.Items.Add(DR.Item("matapelajaran"))
            ComboBox5.Items.Add(DR.Item("matapelajaran"))
        Loop

        'CMD = New OleDbCommand("select distinct jurusan from tblpelajaran", Conn)
        'DR = CMD.ExecuteReader
        'ComboBox4.Items.Clear()
        'Do While DR.Read
        '    ComboBox4.Items.Add(DR.Item("jurusan"))
        'Loop

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        CRV.ReportSource = Nothing
        CRV.SelectionFormula = "{tblsiswa.kelas}='" & ComboBox1.Text & "'"
        cryRpt.Load("siswa.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        CRV.ReportSource = Nothing
        CRV.SelectionFormula = "{tblsiswa.nama}='" & ComboBox2.Text & "'"
        cryRpt.Load("siswa.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        CRV.ReportSource = Nothing
        CRV.SelectionFormula = "{tblpelajaran.matapelajaran} like '*" & ComboBox3.Text & "*'"
        cryRpt.Load("pelajaran.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub

    Private Sub ComboBox4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox4.SelectedIndexChanged
        CRV.ReportSource = Nothing
        CRV.SelectionFormula = "{tblpelajaran.jurusan} like '*" & ComboBox4.Text & "*'"
        cryRpt.Load("pelajaran.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CRV.ReportSource = Nothing
        cryRpt.Load("siswa.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CRV.ReportSource = Nothing
        cryRpt.Load("pelajaran.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        CRV.ReportSource = Nothing
        cryRpt.Load("soal ujian.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub

    Private Sub ComboBox5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox5.SelectedIndexChanged
        CRV.ReportSource = Nothing
        CRV.SelectionFormula = "{tblpelajaran.matapelajaran} like '*" & ComboBox5.Text & "*'"
        cryRpt.Load("soal ujian.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub
End Class