﻿Imports System.Data.OleDb

Public Class MasterSoal

    Sub Idsoal()

        CMD = New OleDbCommand("select id_soal from tblmastersoal order by 1 desc", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If Not DR.HasRows Then
            txtIDSoal.Text = "00001"
        Else
            txtIDSoal.Text = Format(Microsoft.VisualBasic.Right(DR.Item(0), 5) + 1, "00000")
        End If
    End Sub

    Sub Tampilpelajaran()
        CMD = New OleDbCommand("select * from TBLpelajaran order by 1", Conn)
        DR = CMD.ExecuteReader
        ComboBox1.Items.Clear()
        Do While DR.Read
            ComboBox1.Items.Add(DR.Item("IDpelajaran") & Space(2) & DR.Item("Matapelajaran"))
        Loop
    End Sub

    Sub Kosongkan()
        On Error Resume Next
        txtIDSoal.Clear()
        ComboBox1.Text = ""
        txtjumlah.Clear()
        txtkoordinator.Clear()
        txtanggota.Clear()

        lblLokasi.Text = ""
        DGV.Columns.Clear()
        FilePDF.src = Nothing
        'Call Idsoal()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupload.Click
        On Error Resume Next
        'Call Koneksi()
        OpenFileDialog1.Filter = "*.pdf|*.pdf"
        OpenFileDialog1.ShowDialog()
        Me.FilePDF.src = OpenFileDialog1.FileName
        lblLokasi.Text = OpenFileDialog1.FileName
    End Sub

    Private Sub btnTutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTutup.Click
        Me.Close()
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        Call Kosongkan()
        ComboBox1.Enabled = True
        txtjumlah.Enabled = True
    End Sub

    Private Sub MasterSoal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        'Call Idsoal()
        Call Kosongkan()
        Call Tampilpelajaran()
    End Sub

    Private Sub txtjumlah_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtjumlah.KeyDown

        'Try
        If e.KeyCode = Keys.Enter Then
            DGV.Columns.Clear()
            DGV.Columns.Add("Nomor", "Nomor")
            DGV.Columns.Add("Kunci", "Kunci Jawaban")
            For nomor As Integer = 0 To Val(txtjumlah.Text) - 1
                DR.Read()
                DGV.RowCount = DGV.RowCount + 1
                DGV.Rows(nomor).Cells(0).Value = DGV.RowCount - 1
            Next
            DGV.Columns(0).ReadOnly = True
            txtkoordinator.Focus()
        End If
        'Catch ex As Exception
        '    MsgBox("hapus data dari bawah keatas dengan menekan ESC dan sisakan sebanyak butir soal")
        'End Try
    End Sub


    Private Sub txtjumlah_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtjumlah.KeyPress
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9" Or e.KeyChar = vbBack) Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click

        Try
            If ComboBox1.Text = "" Or txtjumlah.Text = "" Or txtanggota.Text = "" Or txtkoordinator.Text = "" Or lblLokasi.Text = "" Then
                MsgBox("data belum lengkap")
                Exit Sub
            Else
                CMD = New OleDbCommand("select * from tblmastersoal where id_soal='" & txtIDSoal.Text & "'", Conn)
                DR = CMD.ExecuteReader
                DR.Read()
                If Not DR.HasRows Then
                    Dim simpanmastersoal As String = "insert into TBLmastersoal values('" & txtIDSoal.Text & "','" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "','" & txtjumlah.Text & "','" & txtkoordinator.Text & "','" & txtanggota.Text & "','" & lblLokasi.Text & "')"
                    CMD = New OleDbCommand(simpanmastersoal, Conn)
                    CMD.ExecuteNonQuery()
                Else
                    Dim editmastersoal As String = "update TBLmastersoal set idpelajaran='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "',jumlah_soal='" & txtjumlah.Text & "',koordinator='" & txtkoordinator.Text & "',anggota='" & txtanggota.Text & "',lokasi='" & lblLokasi.Text & "' where id_soal='" & txtIDSoal.Text & "'"
                    CMD = New OleDbCommand(editmastersoal, Conn)
                    CMD.ExecuteNonQuery()
                End If

                For baris As Integer = 0 To DGV.RowCount - 2
                    'Call Koneksi()
                    CMD = New OleDbCommand("select id_soal,Nomor,Jawaban from tblsoal where id_soal='" & txtIDSoal.Text & "' and idpelajaran='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "' and val(nomor)='" & DGV.Rows(baris).Cells(0).Value & "'", Conn)
                    DR = CMD.ExecuteReader
                    DR.Read()
                    If DR.HasRows Then
                        'Call Koneksi()
                        'jika data sudah ada, maka lakukan edit - update
                        Dim edit As String = "update tblsoal set jawaban='" & DGV.Rows(baris).Cells(1).Value & "' where id_soal='" & txtIDSoal.Text & "' and VAL(nomor)='" & DGV.Rows(baris).Cells(0).Value & "' and idpelajaran='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "'"

                        CMD = New OleDbCommand(edit, Conn)
                        CMD.ExecuteNonQuery()
                    Else
                        Call Koneksi()
                        'jika data belum ada maka lakukan insert 
                        Dim simpan As String = "insert into tblsoal values ('" & txtIDSoal.Text & "','" & Microsoft.VisualBasic.Left(ComboBox1.Text, 3) & "','" & DGV.Rows(baris).Cells(0).Value & "','" & DGV.Rows(baris).Cells(1).Value & "')"
                        CMD = New OleDbCommand(simpan, Conn)
                        CMD.ExecuteNonQuery()
                    End If
                Next

                MsgBox("data berhasil disimpan")
                Call Kosongkan()
                ComboBox1.Enabled = True
                txtjumlah.Enabled = True
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    'Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
    '    txtIDSoal.Enabled = True
    'End Sub

    Private Sub txtIDSoal_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtIDSoal.KeyDown
        If e.KeyCode = Keys.Enter Then
            CMD = New OleDbCommand("select * from tblmastersoal where id_soal='" & txtIDSoal.Text & "'", Conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If DR.HasRows Then
                On Error Resume Next
                ComboBox1.Text = DR.Item("idpelajaran")
                ComboBox1.Enabled = False
                txtjumlah.Text = DR.Item("jumlah_soal")
                txtjumlah.Enabled = False
                txtkoordinator.Text = DR.Item("koordinator")
                txtanggota.Text = DR.Item("anggota")
                lblLokasi.Text = DR.Item("lokasi")
                FilePDF.src = lblLokasi.Text

                DA = New OleDbDataAdapter("select Nomor,Jawaban from tblsoal where id_soal='" & txtIDSoal.Text & "'", Conn)
                DS = New DataSet
                DA.Fill(DS)
                DGV.DataSource = DS.Tables(0)
                DGV.Columns(0).ReadOnly = True
            Else
                MsgBox("id soal tidak ditemukan")
            End If
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Call Idsoal()
    End Sub

    Private Sub DGV_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellEndEdit
        If e.ColumnIndex = 1 Then
            DGV.Rows(e.RowIndex).Cells(1).Value = UCase(DGV.Rows(e.RowIndex).Cells(1).Value)
        End If
    End Sub

   
    Private Sub DGV_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DGV.KeyDown
        On Error Resume Next

        If e.KeyCode = Keys.Escape Or e.KeyCode = Keys.Delete Then
            DGV.Rows.Remove(DGV.CurrentRow)
        End If
    End Sub

    Private Sub txtkoordinator_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtkoordinator.KeyDown
        If e.KeyCode = Keys.Enter Then
            txtanggota.Focus()
        End If
    End Sub

End Class