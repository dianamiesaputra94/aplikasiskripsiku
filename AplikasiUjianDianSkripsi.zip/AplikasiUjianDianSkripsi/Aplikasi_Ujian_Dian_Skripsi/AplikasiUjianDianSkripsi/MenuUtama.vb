﻿Imports System.Data.OleDb

Public Class MenuUtama

    Private Sub UserToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        User.Show()
    End Sub

    Private Sub SiswaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        DataSiswa.Show()
    End Sub

    Private Sub MataKuliahToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        DataPelajaran.Show()
    End Sub

    Private Sub SoalUjianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'SoalUjian.Show()
    End Sub

    Private Sub UjianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Ujian.Show()
    End Sub

    Private Sub MasterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        LaporanMaster.Show()
    End Sub

    Private Sub HasilUjianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        LaporanNilai.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If MessageBox.Show("Tutup aplikasi...?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            End
        End If
    End Sub

    Private Sub MenuUtama_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If e.KeyChar = Chr(27) Then
            If MessageBox.Show("Tutup aplikasi...?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                End
            End If
        End If
    End Sub

    Private Sub MenuUtama_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        'Label3.Visible = False
        GroupBox1.Visible = False
        If Panel3.Text = "ADMIN" Then
            GroupBox1.Visible = True
        End If
        'GroupBox1.Visible = True
        'PictureBox1.Load("bgok.gif")
        'PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        ListBox1.Visible = False
        Call Koneksi()
        CMD = New OleDbCommand("select * from tblsiswa", Conn)
        DR = CMD.ExecuteReader
        ListBox1.Items.Clear()
        Do While DR.Read
            ListBox1.Items.Add(DR.Item("pwd") & Space(2) & DR.Item("nama"))
        Loop

        '============================================
        CMD = New OleDbCommand("select * from tblsekolah", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Label1.Text = DR.Item(1) & Space(2) & DR.Item(2) & Space(2) & DR.Item(3) & Space(2) & DR.Item(4) & Space(2) & DR.Item(5) & Space(2) & DR.Item(6)

            Label2.Text = DR.Item(1) & Space(2) & DR.Item(2) & Space(2) & DR.Item(3) & Space(2) & DR.Item(4) & Space(2) & DR.Item(5) & Space(2) & DR.Item(6)
        Else
            Label1.Text = ""
            Label2.Text = ""
        End If
    End Sub

    Private Sub AdminToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Login.Show()
    End Sub

    Private Sub PesertaUjianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        LoginPeserta.Show()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        User.Show()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        DataSiswa.Show()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        DataPelajaran.Show()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        MasterSoal.Show()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        UjianSiswa.Show()
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        LaporanMaster.Show()
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        LaporanNilai.Show()
    End Sub

    Private Sub Button13_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        Panel1.Text = ""
        Panel2.Text = ""
        Panel3.Text = ""
        Login.txtnama.Clear()
        Login.txtpassword.Clear()
        LoginPeserta.txtnama.Clear()
        LoginPeserta.txtpassword.Clear()
        GroupBox1.Visible = False
        GroupBox2.Visible = True
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        If MessageBox.Show("Apakah anda ingin menutup aplikasi ?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            End
        End If
    End Sub

    Private Sub Button24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button24.Click
        Login.Show()
    End Sub

    Private Sub Button23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button23.Click
        LoginPeserta.Show()
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        If MessageBox.Show("Apakah anda ingin menutup aplikasi?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            End
        End If
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        MasterSekolah.Show()
    End Sub
End Class