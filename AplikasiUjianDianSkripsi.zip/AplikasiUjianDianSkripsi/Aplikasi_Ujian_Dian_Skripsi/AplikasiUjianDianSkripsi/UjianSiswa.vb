﻿Imports System.Data.OleDb
Imports System.Math

Public Class UjianSiswa

    Private Sub UjianSiswa_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lbltanggal.Text = Format(Today, "MM/dd/yyyy")
        Call Koneksi()
        'tampilkan mata pelajaran yang cocok dengan hasil login yang tercantum di panel1 menu utama (sesuai jurusan)
        'CMD = New OleDbCommand("select * from tblpelajaran WHERE LEFT(IDpelajaran,1)='" & Trim(Microsoft.VisualBasic.Mid(MenuUtama.Panel1.Text, 4, 1)) & "'", Conn)

        'CMD = New OleDbCommand("select * from tblmastersoal WHERE LEFT(IDpelajaran,1)='" & Trim(Microsoft.VisualBasic.Mid(MenuUtama.Panel1.Text, 4, 1)) & "'", Conn)
        'CMD = New OleDbCommand("SELECT TBLMasterSoal.ID_SOAL FROM TBLPelajaran INNER JOIN TBLMasterSoal ON TBLPelajaran.IDPelajaran = TBLMasterSoal.IDPelajaran where tblpelajaran.kelas='" & lblkelas.Text & "'", Conn)
        CMD = New OleDbCommand("SELECT TBLMasterSoal.ID_SOAL FROM TBLPelajaran INNER JOIN TBLMasterSoal ON TBLPelajaran.IDPelajaran = TBLMasterSoal.IDPelajaran", Conn)

        DR = CMD.ExecuteReader
        cmbidsoal.Items.Clear()
        Do While DR.Read
            cmbidsoal.Items.Add(DR.Item("id_soal")) ' & Space(5) & DR.Item("matapelajaran"))
        Loop
        lbldurasi.Text = 0
        lbljumlahsoal.Text = 0
        lbljumlahdijawab.Text = 0
        lbljumlahbenar.Text = 0
        lbljumlahsalah.Text = 0
        lblketerangan.Text = "-"
        DGV.ReadOnly = True
        DGV.Rows.Clear()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbidsoal.SelectedIndexChanged

        CMD = New OleDbCommand("select id_soal,Lokasi,tblpelajaran.idpelajaran,matapelajaran,kkm from tblmastersoal,tblpelajaran where tblmastersoal.idpelajaran=tblpelajaran.idpelajaran and tblmastersoal.id_soal='" & cmbidsoal.Text & "' order by 1", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Label30.Text = DR.Item("matapelajaran")
            FileSoal.src = DR.Item("Lokasi")
            tidpelajaran.Text = DR("idpelajaran")
            tbataslulus.Text = DR("kkm")
        End If
        'cari data nis yang pernah melakukan ujian di mata pelajaran yang dipilih di combobox1
        CMD = New OleDbCommand("select * from tblmasterjawaban where nis='" & lblnis.Text & "' and idpelajaran='" & (tidpelajaran.Text) & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            'jika sudah ada maka tampilkan pesan
            MsgBox("Anda sudah mengikuti test mata pelajaran ini " & Chr(13) & _
                    "Tanggal    :" & Format(DR.Item("tanggal"), "dd-MMM-yyyy") & " " & Chr(13) & _
                    "Mulai      :" & Format(DR.Item("Mulai"), "hh:mm:ss") & " " & vbCrLf & _
                    "Selesai    :" & Format(DR.Item("selesai"), "hh:mm:ss") & " " & vbCrLf & _
                    "Jml Soal   :" & DR.Item("jmlsoal") & " " & vbCrLf & _
                    "Dijawab    :" & DR.Item("dijawab") & " " & vbCrLf & _
                    "Jml Benar  :" & DR.Item("benar") & " " & vbCrLf & _
                    "Jml Salah  :" & DR.Item("salah") & " " & vbCrLf & _
                    "Keterangan :" & DR.Item("keterangan") & " ")
            BTNSelesai.Enabled = False
            Exit Sub
        End If

        'jika belum ada maka tampilkan nomor soal ujiannya
        CMD = New OleDbCommand("select nomor from tblsoal where id_soal='" & cmbidsoal.Text & "' order by 1", Conn)
        DR = CMD.ExecuteReader
        ListBox1.Items.Clear()
        Do While DR.Read
            ListBox1.Items.Add(DR.Item("Nomor"))
        Loop

       
        ListBox1.Focus()
    End Sub


    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        On Error Resume Next
        Call BersihkanJawaban()
        'tampilkan pertanyaan soal ujian dalam textbox1 sesuai dengan nomor soal yang dipilih
        CMD = New OleDbCommand("select * from tblsoal where idpelajaran='" & Microsoft.VisualBasic.Left(cmbidsoal.Text, 3) & "' and VAL(nomor)='" & Val(ListBox1.Text) & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            'TextBox1.Text = DR.Item("pertanyaan")
            RadioButton1.Text = DR.Item("A")
            RadioButton2.Text = DR.Item("B")
            RadioButton3.Text = DR.Item("C")
            RadioButton4.Text = DR.Item("D")
        End If
    End Sub

    Sub BersihkanJawaban()
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False
        RadioButton4.Checked = False
    End Sub

    Private Sub RadioButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton1.Click
        'jika jawaban A dipilih maka lakukan proses penyesuaian jawaban apakah benar atau salah
        CMD = New OleDbCommand("select * from tblsoal where ID_SOAL='" & cmbidsoal.Text & "' and VAL(nomor)='" & ListBox1.Text & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            lbldijawab.Text = "A"
            lbljawaban.Text = DR.Item("Jawaban")
            If lbldijawab.Text = lbljawaban.Text Then lblstatus.Text = "BENAR" Else lblstatus.Text = "SALAH"
        End If
    End Sub

    Private Sub RadioButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton2.Click
        'jika jawaban B dipilih maka lakukan proses penyesuaian jawaban apakah benar atau salah
        CMD = New OleDbCommand("select * from tblsoal where ID_SOAL='" & cmbidsoal.Text & "' and VAL(nomor)='" & ListBox1.Text & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            lbldijawab.Text = "B"
            lbljawaban.Text = DR.Item("Jawaban")
            If lbldijawab.Text = lbljawaban.Text Then lblstatus.Text = "BENAR" Else lblstatus.Text = "SALAH"
        End If
    End Sub

    Private Sub RadioButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton3.Click
        'jika jawaban C dipilih maka lakukan proses penyesuaian jawaban apakah benar atau salah
        CMD = New OleDbCommand("select * from tblsoal where ID_SOAL='" & cmbidsoal.Text & "' and VAL(nomor)='" & ListBox1.Text & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            lbldijawab.Text = "C"
            lbljawaban.Text = DR.Item("Jawaban")
            If lbldijawab.Text = lbljawaban.Text Then lblstatus.Text = "BENAR" Else lblstatus.Text = "SALAH"
        End If
    End Sub

    Private Sub RadioButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton4.Click
        'jika jawaban D dipilih maka lakukan proses penyesuaian jawaban apakah benar atau salah
        CMD = New OleDbCommand("select * from tblsoal where ID_SOAL='" & cmbidsoal.Text & "' and VAL(nomor)='" & ListBox1.Text & "'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            lbldijawab.Text = "D"
            lbljawaban.Text = DR.Item("Jawaban")
            If lbldijawab.Text = lbljawaban.Text Then lblstatus.Text = "BENAR" Else lblstatus.Text = "SALAH"
        End If
    End Sub


    Private Sub BTNJawab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNJawab.Click


        'jika mata pelajaran belum dipilih
        If cmbidsoal.Text = "" Then
            MsgBox("Anda belum memilih mata pelajaran")
            Exit Sub
        End If
        'jika belum memeilih nomor soal
        If ListBox1.Text = "" Then
            MsgBox("Anda belum memilih nomor soal")
            Exit Sub
        End If

        'jika belum memilih jawaban
        If RadioButton1.Checked = False And RadioButton2.Checked = False And RadioButton3.Checked = False And RadioButton4.Checked = False Then
            MsgBox("Anda belum memilih jawaban")
            Exit Sub
        End If

        'jika nomor soal tersebut sudah dijawab
        For BARIS As Integer = 0 To DGV.RowCount - 1
            If ListBox1.Text = DGV.Rows(BARIS).Cells(0).Value Then
                MsgBox("Nomor ini sudah dijawab")
                Exit Sub
            End If
        Next
        'jawaban akan tampil di dalam grid sebelah kanan
        DGV.Rows.Add(ListBox1.Text, lbldijawab.Text, lbljawaban.Text, lblstatus.Text)
        ListBox1.Focus()
        ListBox1.SelectedItem = ListBox1.SelectedItem + 1
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        lblmulai.Text = TimeOfDay
        Timer1.Enabled = False
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        lblselesai.Text = TimeOfDay
    End Sub

    'membuat fungsi untuk menghitung jumlah jawaban yang benar
    Sub JumlahBenar()
        Dim hitung As Integer = 0
        For baris As Integer = 0 To DGV.RowCount - 2
            If DGV.Rows(baris).Cells(3).Value = "BENAR" Then
                hitung = hitung + 1
                lbljumlahbenar.Text = hitung
            End If
        Next
    End Sub

    'membuat fungsi untuk menghitung jumlah jawaban yang benar
    Sub JumlahSalah()
        Dim hitung As Integer = 0
        For baris As Integer = 0 To DGV.RowCount - 2
            If DGV.Rows(baris).Cells(3).Value = "SALAH" Then
                hitung = hitung + 1
                lbljumlahsalah.Text = hitung
            End If
        Next
    End Sub

    Private Sub BTNSelesai_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNSelesai.Click
        Try
            'ketika BTNselesai di klik maka....
            Timer2.Enabled = False
            Dim awal As Date = TimeValue(lblmulai.Text)
            Dim hasil As TimeSpan = Now - awal
            'hitung durasi pengerjaan soal ujian
            lbldurasi.Text = (String.Format("{0}:{1}:{2}", hasil.Hours, hasil.Minutes, hasil.Seconds))

            'hitung banyaknya nomor soal ujian
            lbljumlahsoal.Text = ListBox1.Items.Count
            lbljumlahdijawab.Text = DGV.RowCount - 1

            Call JumlahBenar()
            Call JumlahSalah()
            'jika jumlah benar > jumlah salah maka "LULUS"
            'Persentase (%) = (bagian/seluruh) x 100.

            tpersen.Text = Val(lbljumlahbenar.Text) / Val(lbljumlahsoal.Text) * 100
            If Val(tpersen.Text) >= Val(tbataslulus.Text) Then
                lblketerangan.Text = "LULUS"
            Else
                lblketerangan.Text = "GAGAL"
            End If

            'simoan semua hasil ujian ke tabel detail jawaban
            For baris As Integer = 0 To DGV.RowCount - 2
                Dim simpandetail As String = "insert into tbldetailjawaban values ('" & lblnis.Text & "','" & cmbidsoal.Text & "','" & tidpelajaran.Text & "','" & DGV.Rows(baris).Cells(0).Value & "','" & DGV.Rows(baris).Cells(1).Value & "','" & DGV.Rows(baris).Cells(2).Value & "','" & DGV.Rows(baris).Cells(3).Value & "')"
                CMD = New OleDbCommand(simpandetail, Conn)
                CMD.ExecuteNonQuery()
            Next

            'simpan summary hasil ujian ke tabel master jawaban
            Dim simpanmaster As String = "insert into tblmasterjawaban values ('" & lblnis.Text & "','" & cmbidsoal.Text & "','" & tidpelajaran.Text & "','" & lbltanggal.Text & "','" & lblmulai.Text & "','" & lblselesai.Text & "','" & lbldurasi.Text & "','" & lbljumlahsoal.Text & "','" & lbljumlahdijawab.Text & "','" & lbljumlahbenar.Text & "','" & lbljumlahsalah.Text & "','" & tpersen.Text & "','" & lblketerangan.Text & "')"
            CMD = New OleDbCommand(simpanmaster, Conn)
            CMD.ExecuteNonQuery()

            cmbidsoal.Enabled = False
            ListBox1.Enabled = False
            BTNJawab.Enabled = False
            RadioButton1.Enabled = False
            RadioButton2.Enabled = False
            RadioButton3.Enabled = False
            RadioButton4.Enabled = False
            BTNSelesai.Enabled = False
            cmbidsoal.Text = ""
            ListBox1.Items.Clear()
            'TextBox1.Clear()
            Call BersihkanJawaban()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BTNTutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNTutup.Click
        cmbidsoal.Text = ""
        ListBox1.Items.Clear()
        'TextBox1.Clear()
        DGV.Rows.Clear()
        Me.Close()
    End Sub

    Private Sub BTNPetunjuk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNPetunjuk.Click
        MsgBox("1. Pilih Materi di combo paling atas" & Chr(13) & _
        "2. Pilih Nomor Soal dalam list di sebelah kiri" & Chr(13) & _
        "3. Pilih Jawaban pada option button" & vbCrLf & _
        "4. Klik Jawab" & vbCrLf & _
        "5. Lanjutkan ke soal nomor Berikutnya")
    End Sub

    Private Sub BTNBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNBatal.Click
        cmbidsoal.Text = ""
        ListBox1.Items.Clear()
        Label30.Text = ""
        DGV.Rows.Clear()
        Call BersihkanJawaban()
    End Sub
End Class
