﻿Imports System.Data.OleDb

Public Class LoginPeserta

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnama.KeyPress
        If e.KeyChar = Chr(13) Then
            txtpassword.Focus()
        End If
    End Sub

    Private Sub txtpassword_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtpassword.KeyDown
        txtpassword.MaxLength = 4
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpassword.KeyPress
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Try
            'Call Koneksi()
            CMD = New OleDbCommand("select * from tblsiswa where nama='" & txtnama.Text & "' and Pwd='" & txtpassword.Text & "'", Conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If Not DR.HasRows Then
                MsgBox("Login gagal")
                txtnama.Clear()
                txtpassword.Clear()
                txtnama.Focus()
                'MenuUtama.ListBox1.Visible = True
            Else
                Me.Visible = False
                MenuUtama.Show()
                MenuUtama.ListBox1.Visible = False
                MenuUtama.Panel1.Text = DR.Item("nis")
                MenuUtama.Panel2.Text = DR.Item("nama")
                'MenuUtama.Panel3.Text = DR.Item("kelas")
                'MenuUtama.Panel4.Text = DR.Item("semester")
                Dim nis As String = DR.Item("nis")
                Dim nama As String = DR.Item("nama")
                Dim Kelas As String = DR.Item("kELAS")
                'Dim semester As String = DR.Item("semester")
                UjianSiswa.Show()
                UjianSiswa.lblnis.Text = nis 'MenuUtama.Panel1.Text
                UjianSiswa.lblnamasiswa.Text = nama 'MenuUtama.Panel2.Text
                UjianSiswa.lblkelas.Text = Kelas 'MenuUtama.Panel3.Text
                'UjianSiswa.lblsmt.Text = MenuUtama.Panel1.Text 

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub LoginPeserta_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
    End Sub

End Class

