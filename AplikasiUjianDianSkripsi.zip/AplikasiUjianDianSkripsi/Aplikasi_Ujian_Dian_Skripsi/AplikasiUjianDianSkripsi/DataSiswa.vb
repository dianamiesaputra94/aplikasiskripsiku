﻿Imports System.Data.OleDb

Public Class DataSiswa

    Sub Tampilgrid()
        DA = New OleDbDataAdapter("select * from TBLSiswa", Conn)
        DS = New DataSet
        DA.Fill(DS)
        DGV.DataSource = DS.Tables(0)
        DGV.ReadOnly = True
    End Sub

    Sub ketemu()
        tnis.Enabled = False
        tnama.Text = DR(1)
        tkelas.Text = DR(2)
        tnama.Focus()
    End Sub

    Sub Kosongkan()
        tnis.Clear()
        tnis.Enabled = True
        tnama.Clear()
        tkelas.Clear()
        TextBox4.Clear()
        tnis.Focus()
    End Sub

    Sub databaru()
        tnama.Clear()
        tkelas.Clear()
        TextBox4.Clear()
        tnama.Focus()
    End Sub

    Private Sub DataSiswa_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call Tampilgrid()
    End Sub
    
    Private Sub tnis_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tnis.KeyDown
        tnis.MaxLength = 4
        If e.KeyCode = Keys.Enter Then
            CMD = New OleDbCommand("select * from TBLSiswa where NIS='" & tnis.Text & "'", Conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If DR.HasRows Then
                Call ketemu()
            Else
                Call databaru()
            End If
        End If
    End Sub


    Private Sub tnama_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tnama.KeyDown
        If e.KeyCode = Keys.Enter Then
            tkelas.Focus()
        End If
    End Sub

    Private Sub tkelas_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles tkelas.KeyDown
        If e.KeyCode = Keys.Enter Then
            Button1.Focus()
        End If
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If tnis.Text = "" Or tnama.Text = "" Or tkelas.Text = "" Then
            MsgBox("data belum lengkap")
            Exit Sub
        Else
            Call Koneksi()
            'cari data siswa
            CMD = New OleDbCommand("select * from TBLSiswa where NIS='" & tnis.Text & "'", Conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If Not DR.HasRows Then
                Call Koneksi()
                'jika tidak ditemukan maka simpan
                Dim simpan As String = "insert into TBLSiswa values('" & tnis.Text & "','" & tnama.Text & "','" & tkelas.Text & "','" & tnis.Text & "')"
                CMD = New OleDbCommand(simpan, Conn)
                CMD.ExecuteNonQuery()
            Else
                Call Koneksi()
                'jika ditemukan maka edit (update)
                Dim edit As String = "update TBLSiswa set Nama='" & tnama.Text & "',kelas='" & tkelas.Text & "' where NIS='" & tnis.Text & "'"
                CMD = New OleDbCommand(edit, Conn)
                CMD.ExecuteNonQuery()
            End If
            Call Kosongkan()
            Call Tampilgrid()
        End If
    End Sub


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Call Kosongkan()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If tnama.Text = "" Then
            MsgBox("NIS harus diisi dulu")
            tnama.Focus()
            Exit Sub
        Else
            If MessageBox.Show("hapus data ini...?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call Koneksi()
                Dim hapus As String = "delete from TBLSiswa where NIS='" & tnis.Text & "'"
                CMD = New OleDbCommand(hapus, Conn)
                CMD.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilgrid()
            Else
                Call Kosongkan()
            End If
        End If
    End Sub

    Private Sub DGV_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DGV.CellMouseClick
        On Error Resume Next
        tnis.Enabled = False
        tnis.Text = DGV.Rows(e.RowIndex).Cells(0).Value
        tnama.Text = DGV.Rows(e.RowIndex).Cells(1).Value
        tkelas.Text = DGV.Rows(e.RowIndex).Cells(2).Value
        tnama.Focus()
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tkelas.KeyPress
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        Call Koneksi()
        CMD = New OleDbCommand("select * from TBLSiswa where Nama like '%" & TextBox4.Text & "%'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Call Koneksi()
            DA = New OleDbDataAdapter("select * from TBLSiswa where Nama like '%" & TextBox4.Text & "%'", Conn)
            DS = New DataSet
            DA.Fill(DS)
            DGV.DataSource = DS.Tables(0)
        Else
            MsgBox("Nama user tidak ditemukan")
        End If
    End Sub

  

End Class