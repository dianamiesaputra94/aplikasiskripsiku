﻿Imports System.Data.OleDb

Public Class LaporanNilai

    Private Sub LaporanNilai_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        CMD = New OleDbCommand("select distinct kelas from tblsiswa,tblmasterjawaban where tblsiswa.NIS=tblmasterjawaban.NIS", Conn)
        DR = CMD.ExecuteReader
        ComboBox1.Items.Clear()
        Do While DR.Read
            ComboBox1.Items.Add(DR.Item("kelas"))
            ListBox1.Items.Add(DR.Item("kelas"))
        Loop

        CMD = New OleDbCommand("select distinct matapelajaran from tblpelajaran,tblmasterjawaban where tblpelajaran.idpelajaran=tblmasterjawaban.idpelajaran", Conn)
        DR = CMD.ExecuteReader
        ComboBox2.Items.Clear()
        Do While DR.Read
            ComboBox2.Items.Add(DR.Item("matapelajaran"))
        Loop

        CMD = New OleDbCommand("select distinct NIS from tblmasterjawaban", Conn)
        DR = CMD.ExecuteReader
        ComboBox3.Items.Clear()
        Do While DR.Read
            ComboBox3.Items.Add(DR.Item("NIS"))
        Loop

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CRV.ReportSource = Nothing
        CRV.SelectionFormula = "{tblsiswa.kelas}='" & ComboBox1.Text & "' and {tblpelajaran.matapelajaran}='" & ComboBox2.Text & "'"
        cryRpt.Load("nilai per kelas.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CRV.ReportSource = Nothing
        CRV.SelectionFormula = "{tblmasterjawaban.NIS}='" & ComboBox3.Text & "'"
        cryRpt.Load("nilai per NIS.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged


        CRV.ReportSource = Nothing
        CRV.SelectionFormula = "{tblsiswa.kelas}='" & ListBox1.Text & "' "
        cryRpt.Load("nilai per kelas.rpt")
        Call seting_laporan()
        CRV.ReportSource = cryRpt
        CRV.RefreshReport()
    End Sub

    
   
End Class