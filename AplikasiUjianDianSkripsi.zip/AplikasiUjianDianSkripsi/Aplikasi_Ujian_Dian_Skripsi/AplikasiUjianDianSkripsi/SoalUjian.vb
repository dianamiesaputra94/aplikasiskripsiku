﻿Imports System.Data.OleDb

Public Class SoalUjian

    'menampilkan id kuliah dan nama mata kuliah dalam combobox1
    Sub TampilKuliah()
        CMD = New oledbCommand("select * from TBLKuliah order by 1", CONN)
        DR = CMD.ExecuteReader
        ComboBox1.Items.Clear()
        Do While DR.Read
            ComboBox1.Items.Add(DR.Item("IDKuliah") & Space(2) & DR.Item("MataKuliah"))
        Loop
    End Sub

    'membatasi jumlah butir soal antara 5 - 50 dalam combobox2
    Sub JumlahSoal()
        For jumlah As Integer = 5 To 50 Step 5
            ComboBox2.Items.Add(jumlah)
        Next
    End Sub

    Private Sub SoalUjian_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call TampilKuliah()
        Call JumlahSoal()
    End Sub

    Sub AturKolomBaru()
        DGV.Columns.Add("Pertanyaan", "Pertanyaan")
        DGV.Columns(1).Width = 550
        DGV.Columns.Add("A", "Jawaban A") : DGV.Columns(2).Width = 75
        DGV.Columns.Add("B", "Jawaban B") : DGV.Columns(3).Width = 75
        DGV.Columns.Add("C", "Jawaban C") : DGV.Columns(4).Width = 75
        DGV.Columns.Add("D", "Jawaban D") : DGV.Columns(5).Width = 75
        DGV.Columns.Add("Jawaban", "Kunci Jawaban") : DGV.Columns(6).Width = 75
        DGV.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        DGV.Columns.Clear()
        DGV.DataSource = Nothing
        DGV.Refresh()
        DGV.Columns.Add("Nomor", "Nomor")
        DGV.Columns(0).ReadOnly = True
        DGV.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DGV.Columns(0).Width = 50
        'membuat nomor urut soal ujian di kolom pertama
        For baris As Integer = 0 To Val(ComboBox2.Text) - 1
            DGV.RowCount = DGV.RowCount + 1
            DGV.Rows(baris).Cells(0).Value = DGV.RowCount - 1
        Next
        Call AturKolomBaru()
    End Sub

    Sub AturKolomKetemu()
        DGV.Columns(0).Width = 50
        DGV.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DGV.Columns(1).Width = 550
        DGV.Columns(2).Width = 75
        DGV.Columns(3).Width = 75
        DGV.Columns(4).Width = 75
        DGV.Columns(5).Width = 75
        DGV.Columns(6).Width = 75
        DGV.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        For baris As Integer = 0 To DGV.RowCount - 2
            DGV.Rows(baris).Cells(0).ReadOnly = True
        Next
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Call Koneksi()
        CMD = New oledbCommand("select Nomor,Pertanyaan,A,B,C,D,Jawaban from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 5) & "'", CONN)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Call Koneksi()
            DA = New oledbDataAdapter("select Nomor,Pertanyaan,A,B,C,D,Jawaban from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 5) & "' order by 1 ", CONN)
            DS = New DataSet
            DA.Fill(DS)
            DGV.DataSource = DS.Tables(0)
            Call AturKolomKetemu()
            ComboBox2.Enabled = False
        Else
            DGV.Columns.Clear()
            ComboBox2.Enabled = True
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        DGV.Columns.Clear()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ComboBox1.Text = "" Then
            MsgBox("data belum lengkap")
            Exit Sub
        Else
            For baris As Integer = 0 To DGV.RowCount - 2
                Call Koneksi()
                CMD = New OleDbCommand("select Nomor,Pertanyaan,A,B,C,D,Jawaban from tblsoal where idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 5) & "' and val(nomor)='" & DGV.Rows(baris).Cells(0).Value & "'", Conn)
                DR = CMD.ExecuteReader
                DR.Read()
                If DR.HasRows Then
                    Call Koneksi()
                    'jika data sudah ada, maka lakukan edit - update
                    Dim edit As String = "update tblsoal set pertanyaan='" & DGV.Rows(baris).Cells(1).Value & "',A='" & DGV.Rows(baris).Cells(2).Value & "',B='" & DGV.Rows(baris).Cells(3).Value & "',C='" & DGV.Rows(baris).Cells(4).Value & "',D='" & DGV.Rows(baris).Cells(5).Value & "',jawaban='" & DGV.Rows(baris).Cells(6).Value & "' where VAL(nomor)='" & DGV.Rows(baris).Cells(0).Value & "' and idkuliah='" & Microsoft.VisualBasic.Left(ComboBox1.Text, 5) & "'"
                    CMD = New oledbCommand(edit, CONN)
                    CMD.ExecuteNonQuery()
                Else
                    Call Koneksi()
                    'jika data belum ada maka lakukan insert 
                    Dim simpan As String = "insert into tblsoal values ('" & Microsoft.VisualBasic.Left(ComboBox1.Text, 5) & "','" & DGV.Rows(baris).Cells(0).Value & "','" & DGV.Rows(baris).Cells(1).Value & "','" & DGV.Rows(baris).Cells(2).Value & "','" & DGV.Rows(baris).Cells(3).Value & "','" & DGV.Rows(baris).Cells(4).Value & "','" & DGV.Rows(baris).Cells(5).Value & "','" & DGV.Rows(baris).Cells(6).Value & "')"
                    CMD = New oledbCommand(simpan, CONN)
                    CMD.ExecuteNonQuery()
                End If
            Next

            MsgBox("data berhasil disimpan")
            ComboBox1.Text = ""
            ComboBox2.Text = ""
            DGV.Columns.Clear()

        End If
    End Sub


    Private Sub DGV_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellEndEdit
        If e.ColumnIndex = 1 Then
            DGV.Rows(e.RowIndex).Cells(1).Value = UCase(DGV.Rows(e.RowIndex).Cells(1).Value)
            DGV.CurrentCell = DGV(2, DGV.CurrentCell.RowIndex)
            SendKeys.Send("{UP}")
        End If

        If e.ColumnIndex = 2 Then
            DGV.Rows(e.RowIndex).Cells(2).Value = UCase(DGV.Rows(e.RowIndex).Cells(2).Value)
            DGV.CurrentCell = DGV(3, DGV.CurrentCell.RowIndex)
            SendKeys.Send("{UP}")
        End If

        If e.ColumnIndex = 3 Then
            DGV.Rows(e.RowIndex).Cells(3).Value = UCase(DGV.Rows(e.RowIndex).Cells(3).Value)
            DGV.CurrentCell = DGV(4, DGV.CurrentCell.RowIndex)
            SendKeys.Send("{UP}")
        End If

        If e.ColumnIndex = 4 Then
            DGV.Rows(e.RowIndex).Cells(4).Value = UCase(DGV.Rows(e.RowIndex).Cells(4).Value)
            DGV.CurrentCell = DGV(5, DGV.CurrentCell.RowIndex)
            SendKeys.Send("{UP}")
        End If

        If e.ColumnIndex = 5 Then
            DGV.Rows(e.RowIndex).Cells(5).Value = UCase(DGV.Rows(e.RowIndex).Cells(5).Value)
            DGV.CurrentCell = DGV(6, DGV.CurrentCell.RowIndex)
            SendKeys.Send("{UP}")
        End If

        If e.ColumnIndex = 6 Then
            DGV.Rows(e.RowIndex).Cells(6).Value = UCase(DGV.Rows(e.RowIndex).Cells(6).Value)
            DGV.CurrentCell = DGV(1, DGV.CurrentCell.RowIndex)
        End If
    End Sub

End Class