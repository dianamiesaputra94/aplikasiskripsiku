﻿Imports System.Data.OleDb

Public Class User

    Sub Kosongkan()
        txtkode.Enabled = True
        txtkode.Clear()
        txtnama.Clear()
        txtpassword.Clear()
        cmbstatus.Text = ""
        txtkode.Focus()
    End Sub

    Sub DataBaru()
        txtnama.Clear()
        txtpassword.Clear()
        cmbstatus.Text = ""
        txtnama.Focus()
    End Sub

    Sub Tampilgrid()
        'Call Koneksi()
        DA = New oledbDataAdapter("select * from tbluser", CONN)
        DS = New DataSet
        DA.Fill(DS)
        DGV.DataSource = DS.Tables(0)
        DGV.ReadOnly = True
    End Sub

    Private Sub User_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call Tampilgrid()
        Me.CenterToScreen()
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtkode.KeyPress
        txtkode.MaxLength = 5
        If e.KeyChar = Chr(13) Then
            Call Koneksi()
            CMD = New OleDbCommand("select * from tbluser where Kode_user='" & txtkode.Text & "'", Conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If DR.HasRows Then
                txtnama.Text = DR.Item("Nama_User")
                txtpassword.Text = DR.Item("Pass_User")
                cmbstatus.Text = DR.Item("Status_User")
                txtnama.Focus()
            Else
                Call DataBaru()
            End If
        End If
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnama.KeyPress
        txtnama.MaxLength = 30
        If e.KeyChar = Chr(13) Then
            txtpassword.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpassword.KeyPress
        txtpassword.MaxLength = 10
        If e.KeyChar = Chr(13) Then
            cmbstatus.Focus()
        End If
    End Sub

    Private Sub combobox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbstatus.KeyPress
        cmbstatus.MaxLength = 15
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If txtkode.Text = "" Or txtnama.Text = "" Or txtpassword.Text = "" Or cmbstatus.Text = "" Then
            MsgBox("data belum lengkap")
            Exit Sub
        Else
            'Call Koneksi()
            CMD = New OleDbCommand("select * from tbluser where Kode_user='" & txtkode.Text & "'", Conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If Not DR.HasRows Then
                Call Koneksi()
                Dim simpan As String = "insert into tbluser values('" & txtkode.Text & "','" & txtnama.Text & "','" & txtpassword.Text & "','" & UCase(cmbstatus.Text) & "')"
                CMD = New OleDbCommand(simpan, Conn)
                CMD.ExecuteNonQuery()
            Else
                Call Koneksi()
                Dim edit As String = "update tbluser set Nama_User='" & txtnama.Text & "',Pass_User='" & txtpassword.Text & "',Status_User='" & UCase(cmbstatus.Text) & "' where Kode_user='" & txtkode.Text & "'"
                CMD = New OleDbCommand(edit, Conn)
                CMD.ExecuteNonQuery()
            End If
            Call Kosongkan()
            Call Tampilgrid()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If txtkode.Text = "" Then
            MsgBox("Kode_user user harus diisi dulu")
            txtkode.Focus()
            Exit Sub
        Else
            If MessageBox.Show("hapus data ini...?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call Koneksi()
                Dim hapus As String = "delete from tbluser where Kode_user='" & txtkode.Text & "'"
                CMD = New OleDbCommand(hapus, Conn)
                CMD.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilgrid()
            Else
                Call Kosongkan()
            End If
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Call Kosongkan()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcari.TextChanged
        Call Koneksi()
        CMD = New OleDbCommand("select * from tbluser where Nama_User like '%" & txtcari.Text & "%'", Conn)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            Call Koneksi()
            DA = New OleDbDataAdapter("select * from tbluser where Nama_User like '%" & txtcari.Text & "%'", Conn)
            DS = New DataSet
            DA.Fill(DS)
            DGV.DataSource = DS.Tables(0)
        Else
            MsgBox("Nama_User user tidak ditemukan")
        End If
    End Sub

    Private Sub DGV_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DGV.CellMouseClick
        On Error Resume Next
        txtkode.Enabled = False
        txtkode.Text = DGV.Rows(e.RowIndex).Cells(0).Value
        txtnama.Text = DGV.Rows(e.RowIndex).Cells(1).Value
        txtpassword.Text = DGV.Rows(e.RowIndex).Cells(2).Value
        cmbstatus.Text = DGV.Rows(e.RowIndex).Cells(3).Value
    End Sub
End Class