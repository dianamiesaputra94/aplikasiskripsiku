﻿Imports System.Data.OleDb

Public Class Login


    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnama.KeyPress
        If e.KeyChar = Chr(13) Then
            txtpassword.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtpassword.KeyPress
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Try
            'Call Koneksi()
            CMD = New OleDbCommand("select * from tbluser where nama_user='" & txtnama.Text & "' and PASS_user='" & txtpassword.Text & "'", Conn)
            DR = CMD.ExecuteReader
            DR.Read()
            If Not DR.HasRows Then
                MsgBox("Login gagal")
                txtnama.Clear()
                txtpassword.Clear()
                txtnama.Focus()
            Else
                Me.Visible = False
                MenuUtama.Show()
                MenuUtama.Panel1.Text = DR.Item("kode_user")
                MenuUtama.Panel2.Text = DR.Item("nama_user")
                MenuUtama.Panel3.Text = DR.Item("status_user")
                MenuUtama.GroupBox1.Visible = True
                MenuUtama.GroupBox2.Visible = False

                CMD = New OleDbCommand("select * from tblsekolah", Conn)
                DR = CMD.ExecuteReader
                DR.Read()
                If Not DR.HasRows Then
                    MasterSekolah.Show()
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
    End Sub
End Class